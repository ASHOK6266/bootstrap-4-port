function myForm(){
    document.getElementById("myForm").style.display = "block";
  }